export const IMAGES = {
    logo: "https://shorturl.at/mswEV"
}